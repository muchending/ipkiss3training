from collections import Counter
from collections.abc import Sequence
from pathlib import Path
from typing import Any, TypeGuard, Literal

import numpy
import toolz as tlz
import yaml
from numpy import linspace

from ipkiss.primitives.filters.path_to_boundary_filter import PathToBoundaryFilter
from ipkiss.process.layer import PatternPurpose, PPLayer, ProcessLayer, ProcessPurposeLayer
from ipkiss.process.layer_map import GenericGdsiiPPLayerInputMap, GenericGdsiiPPLayerOutputMap
from ipkiss.technology.technology import ProcessTechnologyTree, TechnologyLibrary, TechnologyTree
from ipkiss.visualisation import color, stipple
from ipkiss.visualisation.color import Color
from ipkiss.visualisation.display_style import DisplayStyle, DisplayStyleSet
from ipkiss.visualisation.stipple import StipplePattern
from luceda.technology.defaults import gdsii_filter as default_gdsii_filter

try:
    from ipkiss3 import IPKISS3_LOG as LOG
except ImportError:
    from ipkiss3 import LOG

from .defaults import UNSET
from .mapping import MAPPING, PROCESS_MAPPING, LAYER_MAPPING
from .colors import to_rgb, to_hex

from .tech_types import PDKTechConfiguration, CustomPattern, LppDisplay, Purpose, Lpp, Layer

try:
    from oatools.to_oa.export_layer_map import AutoOALayerExportMap, AutoOAPurposeExportMap

    HAS_OA = True
except (ImportError, FileNotFoundError, ModuleNotFoundError):
    from luceda.technology.oautils.export_layer_map import AutoOALayerExportMap, AutoOAPurposeExportMap

    HAS_OA = False


def get_tech_data(tech_file_path: str | Path) -> PDKTechConfiguration | None:
    import re

    loader = yaml.FullLoader
    # Ensure 1e-9 (i.e. without a decimal dot) is interpreted as a float
    loader.add_implicit_resolver(
        "tag:yaml.org,2002:float",
        re.compile(
            """^(?:
         [-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+]?[0-9]+)?
        |[-+]?(?:[0-9][0-9_]*)(?:[eE][-+]?[0-9]+)
        |\\.[0-9_]+(?:[eE][-+][0-9]+)?
        |[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*
        |[-+]?\\.(?:inf|Inf|INF)
        |\\.(?:nan|NaN|NAN))$""",
            re.VERBOSE,
        ),
        list("-+0123456789."),
    )
    with open(tech_file_path) as tech_file:
        tech_data: PDKTechConfiguration | None = yaml.load(tech_file, Loader=loader)
        return tech_data


def _ensure_subtree_exists(
    tree: TechnologyTree, subtree: str | list[str], allow_overwrite: bool = True
) -> TechnologyTree:
    if isinstance(subtree, str):
        pth = subtree.split(".")
    else:
        pth = subtree
    for pthseg in pth:
        if not hasattr(tree, pthseg):
            stree = TechnologyTree()
            setattr(tree, pthseg, stree)
            if allow_overwrite:
                tree.overwrite_allowed.append(pthseg)
            tree = stree
        else:
            tree = getattr(tree, pthseg)

    return tree


def _convert_to_ipkiss_pattern_purpose(purpose: Purpose) -> PatternPurpose:
    name = tlz.get_in(("ipkiss", "name"), purpose, default=purpose["name"])
    extension = tlz.get_in(("ipkiss", "extension"), purpose, default=purpose["name"])
    return PatternPurpose(name=name, extension=extension)


def _convert_to_ipkiss_pplayer(processes: TechnologyTree, purposes: TechnologyTree, lpp: Lpp) -> PPLayer:
    layer, purpose = lpp["lpp"]
    name = tlz.get_in(("ipkiss", "name"), lpp, lpp["name"])

    return PPLayer(getattr(processes, layer), getattr(purposes, purpose), name=name)


def _convert_to_ipkiss_process_layer(layer: Layer) -> ProcessLayer:
    name = tlz.get_in(("ipkiss", "name"), layer, default=layer.get("doc", layer["name"]))
    return ProcessLayer(name=name, extension=layer["name"])


def _add_layers_to_tech(tech: TechnologyLibrary, tech_data: PDKTechConfiguration) -> None:
    process_tree = getattr(tech, "PROCESS", None)
    if process_tree is None:
        tech.PROCESS = process_tree = ProcessTechnologyTree()
    # assert id(process_tree) == id(tech.PROCESS)
    process_tree = tech.PROCESS

    for field in ["PURPOSE", "PPLAYER"]:
        _ensure_subtree_exists(tech, field)

    lpp_tree = tech.PPLAYER
    layers = tech_data.get("layers") or []
    purposes = tech_data.get("purposes") or []

    purpose_tree = tech.PURPOSE
    for layer in layers:
        setattr(tech.PROCESS, layer["name"], _convert_to_ipkiss_process_layer(layer))
    for purpose in purposes:
        setattr(tech.PURPOSE, purpose["name"], _convert_to_ipkiss_pattern_purpose(purpose))

    # Add drawing if it hasn't been defined
    #
    if not hasattr(purpose_tree, "DRAWING"):
        purpose_tree.DRAWING = PatternPurpose(name="Drawing", extension="DRW")

    # Implicitly defined PPLAYERs
    drawing_purpose: PatternPurpose = purpose_tree.DRAWING

    if drawing_purpose.extension != "DRW":
        LOG.warning(
            "The drawing purpose is reserved and must not be specified manually",
            stacklevel=3,
        )

    lpps = tech_data.get("lpps") or []

    for lpp in lpps:
        *sub_path, key = tlz.get_in(("ipkiss", "tech_path"), lpp, default=[lpp["name"]])
        if len(sub_path) > 0:
            _ensure_subtree_exists(tech.PPLAYER, sub_path)
        setattr(
            tlz.get_in(sub_path, lpp_tree),
            key,
            _convert_to_ipkiss_pplayer(process_tree, purpose_tree, lpp),
        )
    for layer in layers:
        if not hasattr(lpp_tree, layer["name"]):
            setattr(
                lpp_tree,
                layer["name"],
                PPLayer(
                    name=layer["name"],
                    process=getattr(process_tree, layer["name"]),
                    purpose=drawing_purpose,
                ),
            )


def _resolve_lpp_to_pair(tech_data: PDKTechConfiguration, lpp: str | Sequence[str]) -> tuple[str, str]:
    lpps = tech_data.get("lpps") or []

    if isinstance(lpp, str):
        lpp = next((alias["lpp"] for alias in lpps if alias["name"] == lpp), [lpp, "DRAWING"])
    return lpp[0], lpp[1]


def _resolve_lpp_to_path(tech_data: PDKTechConfiguration, lpp: str | Sequence[str]) -> list[str] | None:
    lpps = tech_data.get("lpps") or []

    if isinstance(lpp, str):
        lpp_data = next((row for row in lpps if row["name"] == lpp), None)
    else:
        lpp_data = next((row for row in lpps if row["lpp"] == list(lpp)), None)

    if lpp_data is None:
        return None

    path = tlz.get_in(("ipkiss", "tech_path"), lpp_data, default=[lpp_data["name"]])
    return path


def _resolve_lpp_to_pplayer(
    tech_data: PDKTechConfiguration, tech: TechnologyLibrary, lpp: str | Sequence[str]
) -> PPLayer | None:
    return tlz.get_in(_resolve_lpp_to_path(tech_data, lpp), tech.PPLAYER)


def _add_gdsii_numbers_to_tech(tech: TechnologyLibrary, tech_data: PDKTechConfiguration) -> None:
    layer_table = tlz.get_in(["gds", "layer_table"], tech_data)

    if layer_table is None:
        return

    _ensure_subtree_exists(tech, "GDSII")

    layertable = {
        (getattr(tech.PROCESS, layer), getattr(tech.PURPOSE, purpose)): tuple(number)
        for layer, purpose, number in (
            (*_resolve_lpp_to_pair(tech_data, row["lpp"]), row["number"]) for row in layer_table
        )
    }

    if not hasattr(tech.GDSII, "LAYERTABLE"):
        tech.GDSII.LAYERTABLE = layertable
    else:
        tech.GDSII.LAYERTABLE.update(layertable)

    tech.GDSII.EXPORT_LAYER_MAP = GenericGdsiiPPLayerOutputMap(
        pplayer_map=tech.GDSII.LAYERTABLE,
        ignore_undefined_mappings=False,
    )
    tech.GDSII.IMPORT_LAYER_MAP = GenericGdsiiPPLayerInputMap(pplayer_map=tech.GDSII.LAYERTABLE)


def _add_gdsii_filter_to_tech(tech: TechnologyLibrary, tech_data: PDKTechConfiguration) -> None:
    export_options = tlz.get_in(["gds", "export_options"], tech_data)
    if export_options is None:
        return

    _ensure_subtree_exists(tech, "GDSII")
    tech.GDSII.FILTER = default_gdsii_filter(tech)

    filter_names = ["cut_path", "path_to_boundary", "cut_boundary", "write_empty", "name_error_filter"]
    for filter_name in filter_names:
        if filter_name in export_options:
            tech.GDSII.FILTER[filter_name] = export_options[filter_name]
    path_to_boundary_filter = tech.GDSII.FILTER._sub_filters[1]
    assert isinstance(path_to_boundary_filter, PathToBoundaryFilter)
    path_to_boundary_layers = export_options.get("path_to_boundary_layers")
    if path_to_boundary_layers:
        path_to_boundary_filter.layers = [
            _resolve_lpp_to_pplayer(tech_data, tech, lpp) for lpp in path_to_boundary_layers
        ]
    path_to_boundary_exclude_layers = export_options.get("path_to_boundary_exclude_layers")
    if path_to_boundary_exclude_layers:
        path_to_boundary_filter.exclude_layers = [
            _resolve_lpp_to_pplayer(tech_data, tech, lpp) for lpp in path_to_boundary_exclude_layers
        ]


def add_tech_values(tech: TechnologyLibrary, tech_data: PDKTechConfiguration, allow_overwrite: bool = True) -> None:
    for ktech, knew in PROCESS_MAPPING.items():
        layer_name = tlz.get_in(knew, tech_data, UNSET)

        if layer_name is UNSET or layer_name is None:
            continue

        if len(ktech) > 1:
            subtree = _ensure_subtree_exists(
                tech,
                ktech[:-1],
                allow_overwrite=allow_overwrite,
            )
        else:
            subtree = tech

        if not hasattr(tech.PROCESS, layer_name):
            LOG.warning(f"{'.'.join(ktech)} couldn not be set as process '{layer_name}' could not be found")
            continue

        tkey = ktech[-1]
        setattr(subtree, tkey, getattr(tech.PROCESS, layer_name))

    for ktech, knew in LAYER_MAPPING.items():
        lpp_ref = tlz.get_in(knew, tech_data, UNSET)

        if lpp_ref is UNSET or lpp_ref is None:
            continue

        if len(ktech) > 1:
            subtree = _ensure_subtree_exists(
                tech,
                ktech[:-1],
                allow_overwrite=allow_overwrite,
            )
        else:
            subtree = tech

        pplayer = _lpp_to_pplayer(tech, tech_data, lpp_ref)
        if pplayer is None:
            LOG.warning(f"{'.'.join(ktech)} couldn not be set as LPP '{lpp_ref}' could not be found")
            continue

        tkey = ktech[-1]
        setattr(subtree, tkey, pplayer)

        if allow_overwrite and hasattr(subtree, "overwrite_allowed"):
            subtree.overwrite_allowed.append(ktech[-1])

    for ktech, knew in MAPPING.items():
        val = tlz.get_in(knew, tech_data, UNSET)

        if val is UNSET:
            continue

        if len(ktech) > 1:
            subtree = _ensure_subtree_exists(
                tech,
                ktech[:-1],
                allow_overwrite=allow_overwrite,
            )
        else:
            subtree = tech

        setattr(subtree, ktech[-1], val)

        if allow_overwrite:
            subtree.overwrite_allowed.append(ktech[-1])


def _convert_to_ipkiss_color(tech_color: str | list[int], name: str | None = None) -> Color:
    if isinstance(tech_color, str):
        _name = tech_color
        r, g, b = to_rgb(tech_color)
    else:
        r, g, b = rgb_color = tuple(c / 255 for c in tech_color)
        _name = to_hex(rgb_color)
    if name is None:
        name = _name
    return Color(name=name, red=r, green=g, blue=b)


def _convert_to_ipkiss_stipple(custom_pattern: CustomPattern) -> StipplePattern:
    pattern = numpy.array([[int(c == "*") for c in line] for line in custom_pattern["lines"]], dtype=numpy.int64)
    return StipplePattern(name=custom_pattern["name"], pattern=pattern)


PREDEFINED_STIPPLES = {
    "no-stipple": "STIPPLE_NONE",
    "dots": "STIPPLE_DOTS",
    "dots-sparse": "STIPPLE_DOTS_SPARSE",
    "lines-horizontal": "STIPPLE_LINES_H",
    "lines-horizontal-dense": "STIPPLE_LINES_H_DENSE",
    "lines-horizontal-bold": "STIPPLE_LINES_H_BOLD",
    "filled": "STIPPLE_FILLED",
    "lines-vertical": "STIPPLE_LINES_V",
    "lines-vertical-dense": "STIPPLE_LINES_V_DENSE",
    "lines-vertical-bold": "STIPPLE_LINES_V_BOLD",
    "lines-diagonal-left": "STIPPLE_LINES_DIAGONAL_L",
    "lines-diagonal-right": "STIPPLE_LINES_DIAGONAL_R",
    "triangle": "STIPPLE_TRIANGLE",
    "solid": "STIPPLE_SOLID",
    "hollow": "STIPPLE_HOLLOW",
    "dotted": "STIPPLE_DOTTED",
    "coarsly-dotted": "STIPPLE_COARSLY_DOTTED",
    "left-hatched": "STIPPLE_LEFT_HATCHED",
    "lightly-left-hatched": "STIPPLE_LIGHTLY_LEFT_HATCHED",
    "strongly-left-hatched-dense": "STIPPLE_STRONGLY_LEFT_HATCHED_DENSE",
    "strongly-left-hatched-sparse": "STIPPLE_STRONGLY_LEFT_HATCHED_SPARSE",
    "right-hatched": "STIPPLE_RIGHT_HATCHED",
    "lightly-right-hatched": "STIPPLE_LIGHTLY_RIGHT_HATCHED",
    "strongly-right-hatched-dense": "STIPPLE_STRONGLY_RIGHT_HATCHED_DENSE",
    "strongly-right-hatched-sparse": "STIPPLE_STRONGLY_RIGHT_HATCHED_SPARSE",
    "cross-hatched": "STIPPLE_CROSS_HATCHED",
    "lightly-cross-hatched": "STIPPLE_LIGHTLY_CROSS_HATCHED",
    "checkerboard-2px": "STIPPLE_CHECKERBOARD_2PX",
    "strongly-cross-hatched-sparse": "STIPPLE_STRONGLY_CROSS_HATCHED_SPARSE",
    "heavy-checkerboard": "STIPPLE_HEAVY_CHECKERBOARD",
    "hollow-bubbles": "STIPPLE_HOLLOW_BUBBLES",
    "solid-bubbles": "STIPPLE_SOLID_BUBBLES",
    "pyramids": "STIPPLE_PYRAMIDS",
    "turned-pyramids": "STIPPLE_TURNED_PYRAMIDS",
    "plus": "STIPPLE_PLUS",
    "minus": "STIPPLE_MINUS",
    "220-5-degree-down": "STIPPLE_220_5_DEGREE_DOWN",
    "220-5-degree-up": "STIPPLE_220_5_DEGREE_UP",
    "670-5-degree-down": "STIPPLE_670_5_DEGREE_DOWN",
    "670-5-degree-up": "STIPPLE_670_5_DEGREE_UP",
    "220-5-cross-hatched": "STIPPLE_220_5_CROSS_HATCHED",
    "zig-zag": "STIPPLE_ZIG_ZAG",
    "sine": "STIPPLE_SINE",
    "special-pattern-for-light-heavy-dithering": "STIPPLE_SPECIAL_PATTERN_FOR_LIGHT_HEAVY_DITHERING",
    "special-pattern-for-light-frame-dithering": "STIPPLE_SPECIAL_PATTERN_FOR_LIGHT_FRAME_DITHERING",
    "vertical-dense": "STIPPLE_VERTICAL_DENSE",
    "vertical": "STIPPLE_VERTICAL",
    "vertical-thick": "STIPPLE_VERTICAL_THICK",
    "vertical-sparse": "STIPPLE_VERTICAL_SPARSE",
    "vertical-sparse-thick": "STIPPLE_VERTICAL_SPARSE_THICK",
    "horizontal-dense": "STIPPLE_HORIZONTAL_DENSE",
    "horizontal": "STIPPLE_HORIZONTAL",
    "horizontal-thick": "STIPPLE_HORIZONTAL_THICK",
    "horizontal-sparse": "STIPPLE_HORIZONTAL_SPARSE",
    "horizontal-sparse-thick": "STIPPLE_HORIZONTAL_SPARSE_THICK",
    "grid-dense": "STIPPLE_GRID_DENSE",
    "grid": "STIPPLE_GRID",
    "grid-thick": "STIPPLE_GRID_THICK",
    "grid-sparse": "STIPPLE_GRID_SPARSE",
    "grid-sparse-thick": "STIPPLE_GRID_SPARSE_THICK",
}


def _lpp_to_pplayer(tech: TechnologyLibrary, tech_data: PDKTechConfiguration, lpp_ref: str | Sequence[str]):
    pth = _resolve_lpp_to_path(tech_data, lpp_ref)
    if pth is None:
        if isinstance(lpp_ref, str):
            process = getattr(tech.PROCESS, lpp_ref)
            purpose = tech.PURPOSE.DRAWING
        else:
            lay, purp = lpp_ref
            process = getattr(tech.PROCESS, lay)
            purpose = getattr(tech.PURPOSE, purp)

        pplayer = ProcessPurposeLayer(process=process, purpose=purpose)
    else:
        pplayer = tlz.get_in(pth, tech.PPLAYER)
    return pplayer


def _add_display_to_tech(tech: TechnologyLibrary, tech_data: PDKTechConfiguration) -> None:
    display = tech_data.get("display") or {}

    _ensure_subtree_exists(tech, "DISPLAY")

    # Extract custom colours
    custom_colors = {
        name: _convert_to_ipkiss_color(tech_color, name=name)
        for name, tech_color in display.get("custom_colors", {}).items()
    }

    def is_pattern(pattern: Any) -> TypeGuard[StipplePattern]:
        return isinstance(pattern, StipplePattern)

    stipples = {
        name: pattern
        for name, stipple_name in PREDEFINED_STIPPLES.items()
        if (pattern := getattr(stipple, stipple_name, None)) is not None and is_pattern(pattern)
    } | {
        custom_pattern["name"]: _convert_to_ipkiss_stipple(custom_pattern)
        for custom_pattern in display.get("custom_patterns", [])
    }

    def _color(tech_color: str | list[int]) -> Color:
        if isinstance(tech_color, str) and tech_color in custom_colors:
            return custom_colors[tech_color]
        return _convert_to_ipkiss_color(tech_color)

    def generate_display_style(lpp: LppDisplay) -> DisplayStyle:
        ret = DisplayStyle()
        ret.color = _color(lpp["color"])

        if "alpha" in lpp:
            ret.alpha = float(lpp["alpha"])
        else:
            ret.alpha = 0.5

        if "pattern" in lpp:
            pattern_name = lpp["pattern"]
            pattern = stipples.get(pattern_name)

            if pattern is not None:
                ret.stipple = pattern
        if "edge_width" in lpp:
            ret.edgewidth = lpp["edge_width"]

        if "edge_color" in lpp:
            ret.edgecolor = _color(lpp["edge_color"])
        return ret

    style_set = DisplayStyleSet()
    style_set.background = DisplayStyle(
        color=color.COLOR_WHITE,
        stipple=stipple.STIPPLE_FILLED,
        edgewidth=0.0,
    )

    lpps = display.get("lpps") or []

    if hasattr(tech.DISPLAY, "DEFAULT_DISPLAY_STYLE_SET"):
        style_set = tech.DISPLAY.DEFAULT_DISPLAY_STYLE_SET
    display_layers = set(lay for lay, _ in style_set)

    for lpp in lpps:
        lpp_ref = lpp["lpp"]
        pplayer = _lpp_to_pplayer(tech, tech_data, lpp_ref)
        dstyle = generate_display_style(lpp)
        if pplayer not in display_layers:
            style_set.append((pplayer, dstyle))

    # Visualization for simple Layers which may be present
    style_set += [
        (
            i,
            DisplayStyle(
                color=color.Color(
                    name="gray_" + str(i),
                    red=c_val,
                    green=c_val,
                    blue=c_val,
                ),
                alpha=0.5,
            ),
        )
        for i, c_val in enumerate(linspace(0.9, 0.0, num=256))
        if i not in display_layers
    ]

    tech.DISPLAY.DEFAULT_DISPLAY_STYLE_SET = style_set


def _assert_unique_oa_numbers(oa_map: dict[Any, int], map_type: Literal["purpose", "layer"]) -> None:
    oa_numbers = Counter(oa_map.values())
    if any(count > 1 for count in oa_numbers.values()):
        duplicates = [number for number, count in oa_numbers.items() if count > 1]
        raise RuntimeError(f"OA number conflict is present in the {map_type} config for numbers {duplicates}.")


def _add_oa_to_tech(tech: TechnologyLibrary, tech_data: PDKTechConfiguration) -> None:
    _ensure_subtree_exists(tech, "OPENACCESS")  # pyright: ignore[reportArgumentType]

    layers = tech_data.get("layers") or []
    purposes = tech_data.get("purposes") or []

    oa_process_map: dict[ProcessLayer, int] = {
        _convert_to_ipkiss_process_layer(layer): layer["number"]
        for layer in layers
        if isinstance(layer.get("number"), int)
    }
    _assert_unique_oa_numbers(oa_process_map, "layer")

    def filter_drawing(purpose: Purpose) -> bool:
        if (name := purpose.get("name", "")) == "DRAWING" or name == "DRW":
            return False

        if (ipkiss_extension := purpose.get("ipkiss", {}).get("extension")) == "DRAWING" or ipkiss_extension == "DRW":
            return False

        return True

    # We filter out the drawing layer to avoid duplication of the purposes in AutoOAPurposeExportMap
    # Drawing purpose is a reserved purpose in the AutoOAPurposeExportMap and is hardcoded to 0xFFFFFFFF
    oa_purpose_map: dict[PatternPurpose, int] = {
        _convert_to_ipkiss_pattern_purpose(purpose): purpose["number"]
        for purpose in filter(filter_drawing, purposes)
        if isinstance(purpose.get("number"), int)
    }
    _assert_unique_oa_numbers(oa_purpose_map, "purpose")

    # TODO (for mac): Use a different non-oa-dependent structure, # so we can access OA numbers
    if not hasattr(tech.OPENACCESS, "EXPORT_PURPOSE_MAP"):
        tech.OPENACCESS.EXPORT_PURPOSE_MAP = AutoOAPurposeExportMap(  # pyright: ignore[reportPossiblyUnboundVariable]
            base_counter=tlz.get_in(("settings", "open_access", "base_counter"), tech_data, 1000),
            known_purposes=oa_purpose_map,
        )

    # TODO (for mac): Use a different non-oa-dependent structure, # so we can access OA numbers
    if not hasattr(tech.OPENACCESS, "EXPORT_LAYER_MAP"):
        tech.OPENACCESS.EXPORT_LAYER_MAP = AutoOALayerExportMap(  # pyright: ignore[reportPossiblyUnboundVariable]
            base_counter=tlz.get_in(("settings", "open_access", "base_counter"), tech_data, 1000),
            known_layers=oa_process_map,
        )

    if not hasattr(tech.OPENACCESS, "FILTER"):
        try:
            tech.OPENACCESS.FILTER = default_gdsii_filter(tech)
        except AttributeError:
            pass


def techfile_to_tech(tech: TechnologyLibrary, tech_file_path: str | Path) -> None:
    tech_data = get_tech_data(tech_file_path)  # noqa
    if tech_data is None:
        tech_data: PDKTechConfiguration = {}
    return data_to_tech(tech, tech_data)


def data_to_tech(tech: TechnologyLibrary, tech_data: PDKTechConfiguration) -> None:
    _add_layers_to_tech(tech, tech_data)
    _add_gdsii_numbers_to_tech(tech, tech_data)
    _add_display_to_tech(tech, tech_data)
    add_tech_values(tech, tech_data)
    _add_gdsii_filter_to_tech(tech, tech_data)  # This one depends on the tech values
    _add_oa_to_tech(tech, tech_data)  # Requires GDSII settings
