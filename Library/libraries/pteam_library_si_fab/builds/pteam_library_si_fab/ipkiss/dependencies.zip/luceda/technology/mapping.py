import argparse
import json
from pathlib import Path
from typing import Any

LAYER_MAPPING = {
    ("WG_DEFAULTS", "CORE_LAYER"): ("waveguides", "wg_defaults_core_layer"),
    ("TRACE", "CONTROL_SHAPE_LAYER"): ("waveguides", "trace_control_shape_layer"),
    ("TRACE", "DEFAULT_LAYER"): ("waveguides", "trace_default_layer"),
    ("PORT", "DEFAULT_LAYER"): ("ports", "default_layer"),
    ("PPLAYER", "M1", "LINE"): ("picazzo", "metal1_layer"),
    ("PPLAYER", "M2", "LINE"): ("picazzo", "metal2_layer"),
    ("PPLAYER", "WG", "TEXT"): ("picazzo", "wg_text"),
    ("PPLAYER", "V12", "PILLAR"): ("picazzo", "via12_layer"),
}

PROCESS_MAPPING = {
    ("PROCESS", "WG"): ("picazzo", "wg_process"),
    ("PROCESS", "RWG"): ("picazzo", "rwg_process"),
    ("PROCESS", "FC"): ("picazzo", "fc_process"),
    ("PROCESS", "SIL"): ("picazzo", "sil_process"),
}

MAPPING: dict[tuple[str, ...], tuple[str, ...]] = {
    ("GDSII", "MAX_COORDINATES"): ("gds", "export_options", "max_coordinates"),
    ("GDSII", "MAX_VERTEX_COUNT"): ("gds", "export_options", "max_vertex_count"),
    ("GDSII", "MAX_PATH_LENGTH"): ("gds", "export_options", "max_path_length"),
    ("GDSII", "MAX_NAME_LENGTH"): ("gds", "export_options", "max_name_length"),
    ("GDSII", "STRNAME_CHARACTER_DICT"): ("gds", "export_options", "strname_character_dict"),
    ("GDSII", "STRNAME_ALLOWED_CHARACTERS"): ("gds", "export_options", "strname_allowed_characters"),
    ("METRICS", "GRID"): ("settings", "metrics", "grid"),
    ("METRICS", "UNIT"): ("settings", "metrics", "unit"),
    ("METRICS", "ANGLE_STEP"): ("settings", "metrics", "angle_step"),
    ("DEFAULT_WAVELENGTH",): ("waveguides", "default_wavelength"),
    ("WG", "BEND_RADIUS"): ("waveguides", "wg_bend_radius"),
    ("WG", "WIRE_WIDTH"): ("waveguides", "wg_wire_width"),
    ("WG", "TRENCH_WIDTH"): ("waveguides", "wg_trench_width"),
    ("WG", "CLADDING_WIDTH"): ("waveguides", "wg_cladding_width"),
    ("WG", "SPACING"): ("waveguides", "wg_spacing"),
    ("WG", "DC_SPACING"): ("waveguides", "wg_dc_spacing"),
    ("WG", "SHORT_STRAIGHT"): ("waveguides", "wg_short_straight"),
    ("WG", "SHORT_TRANSITION_LENGTH"): ("waveguides", "wg_short_transition_length"),
    ("WG", "SHORT_TAPER_LENGTH"): ("waveguides", "wg_short_taper_length"),
    ("WG", "OVERLAP_EXTENSION"): ("waveguides", "wg_overlap_extension"),
    ("WG", "OVERLAP_TRENCH"): ("waveguides", "wg_overlap_trench"),
    ("WG", "EXPANDED_WIDTH"): ("waveguides", "wg_expanded_width"),
    ("WG", "EXPANDED_TAPER_LENGTH"): ("waveguides", "wg_expanded_taper_length"),
    ("WG", "EXPANDED_STRAIGHT"): ("waveguides", "wg_expanded_straight"),
    ("WG", "ANGLE_STEP"): ("waveguides", "wg_angle_step"),
    ("WG", "SLOT_WIDTH"): ("waveguides", "wg_slot_width"),
    ("WG", "SLOTTED_WIRE_WIDTH"): ("waveguides", "wg_slotted_wire_width"),
    ("WG_DEFAULTS", "N_EFF"): ("waveguides", "wg_defaults_n_eff"),
    ("WG_DEFAULTS", "N_GROUP"): ("waveguides", "wg_defaults_n_group"),
    ("WG_DEFAULTS", "LOSS_DB_PERM"): ("waveguides", "wg_defaults_loss_db_perm"),
    ("TRACE", "BEND_RADIUS"): ("waveguides", "trace_bend_radius"),
    ("TRACE", "DRAW_CONTROL_SHAPE"): ("waveguides", "trace_draw_control_shape"),
    ("PORT", "DEFAULT_LENGTH"): ("ports", "default_length"),
    ("BLOCKS", "DEFAULT_YSPACING"): ("blocks", "default_yspacing"),
    ("BLOCKS", "DEFAULT_WIDTH"): ("blocks", "default_width"),
    ("CONTAINER", "TERMINATE_PORTS", "CHILD_SUFFIX"): (
        "picazzo",
        "container_terminate_ports_child_suffix",
    ),
    ("CONTAINER", "TERMINATE_PORTS", "TERMINATION_INSTANCE_PREFIX"): (
        "picazzo",
        "container_terminate_ports_termination_instance_prefix",
    ),
    ("IO", "ADAPTER", "IOFIBCOUP", "CONNECT_TRANSITION_LENGTH"): (
        "picazzo",
        "io_adapter",
        "iofibcoup_connect_transition_length",
    ),
    ("IO", "ADAPTER", "IOFIBCOUP", "FANOUT_LENGTH"): (
        "picazzo",
        "io_adapter",
        "iofibcoup_fanout_length",
    ),
    ("IO", "ADAPTER", "IOFIBCOUP", "FIBER_COUPLER_TRANSITION_LENGTH"): (
        "picazzo",
        "io_adapter",
        "iofibcoup_fiber_coupler_transition_length",
    ),
    ("IO", "ADAPTER", "IOFIBCOUP", "S_BEND_ANGLE"): (
        "picazzo",
        "io_adapter",
        "iofibcoup_s_bend_angle",
    ),
    ("IO", "FIBCOUP", "CURVED", "SOCKET", "MARGIN_FROM_GRATING"): (
        "picazzo",
        "io_fibcoup",
        "curved_socket_margin_from_grating",
    ),
    ("IO", "FIBCOUP", "CURVED", "GRATING", "ANGLE_SPAN"): (
        "picazzo",
        "io_fibcoup",
        "curved_grating_angle_span",
    ),
    ("IO", "FIBCOUP", "CURVED", "GRATING", "BOX_WIDTH"): (
        "picazzo",
        "io_fibcoup",
        "curved_grating_box_width",
    ),
    ("IO", "FIBCOUP", "CURVED", "GRATING", "FOCAL_DISTANCE"): (
        "picazzo",
        "io_fibcoup",
        "curved_grating_focal_distance",
    ),
    ("IO", "FIBCOUP", "CURVED", "GRATING", "N_O_LINES"): (
        "picazzo",
        "io_fibcoup",
        "curved_grating_n_o_lines",
    ),
    ("IO", "FIBCOUP", "CURVED", "GRATING", "PERIOD"): (
        "picazzo",
        "io_fibcoup",
        "curved_grating_period",
    ),
    ("IO", "FIBCOUP", "CURVED", "GRATING", "START_RADIUS"): (
        "picazzo",
        "io_fibcoup",
        "curved_grating_start_radius",
    ),
    ("IO", "FIBCOUP", "CURVED", "SOCKET", "LENGTH"): (
        "picazzo",
        "io_fibcoup",
        "curved_socket_length",
    ),
    ("IO", "FIBCOUP", "CURVED", "SOCKET", "STRAIGHT_EXTENSION"): (
        "picazzo",
        "io_fibcoup",
        "curved_socket_straight_extension",
    ),
    # For si_fab, FIBCOUP.DEFAULT points to FIBCOUP.CURVED
    # ("IO", "FIBCOUP", "DEFAULT", "SOCKET", "LENGTH"): (
    #     "picazzo",
    #     "io_fibcoup",
    #     "default_socket_length",
    # ),
    ("IO", "FIBCOUP", "STRAIGHT", "GRATING", "BOX_WIDTH"): (
        "picazzo",
        "io_fibcoup",
        "straight_grating_box_width",
    ),
    ("IO", "FIBCOUP", "STRAIGHT", "GRATING", "LINE_WIDTH"): (
        "picazzo",
        "io_fibcoup",
        "straight_grating_line_width",
    ),
    ("IO", "FIBCOUP", "STRAIGHT", "GRATING", "N_O_LINES"): (
        "picazzo",
        "io_fibcoup",
        "straight_grating_n_o_lines",
    ),
    ("IO", "FIBCOUP", "STRAIGHT", "GRATING", "PERIOD"): (
        "picazzo",
        "io_fibcoup",
        "straight_grating_period",
    ),
    ("IO", "FIBCOUP", "STRAIGHT", "SOCKET", "LENGTH"): (
        "picazzo",
        "io_fibcoup",
        "straight_socket_length",
    ),
    ("MODULATORS", "PHASESHIFTER", "LATPN", "BRIDGE_PITCH"): (
        "picazzo",
        "modulators",
        "phaseshifter_latpn_bridge_pitch",
    ),
    ("MODULATORS", "PHASESHIFTER", "LATPN", "BRIDGE_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_latpn_bridge_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "LATPN", "JUNCTION_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_latpn_junction_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "LONGPN", "N_LENGTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_longpn_n_length",
    ),
    ("MODULATORS", "PHASESHIFTER", "LONGPN", "N_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_longpn_n_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "LONGPN", "P_LENGTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_longpn_p_length",
    ),
    ("MODULATORS", "PHASESHIFTER", "LONGPN", "P_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_longpn_p_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "JUNCTION_OVERLAP"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_junction_overlap",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "NPLUS_EXTENSION"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_nplus_extension",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "NPLUS_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_nplus_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "NPLUS_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_nplus_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_CONT_OFFSETS"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_cont_offsets",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_CONT_PITCH"): (
        "picazzo",
        "modulators",
        "phaseshiftern_pn_n_cont_pitch",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_METAL1_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_metal1_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_METAL1_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_metal1_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_SIL_EXTENSION"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_sil_extension",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_SIL_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_sil_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_SIL_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_sil_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "N_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_n_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "PPLUS_EXTENSION"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_pplus_extension",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "PPLUS_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_pplus_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "PPLUS_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_pplus_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_CONT_OFFSETS"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_cont_offsets",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_CONT_PITCH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_cont_pitch",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_METAL1_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_metal1_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_METAL1_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_metal1_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_SIL_EXTENSION"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_sil_extension",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_SIL_OFFSET"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_sil_offset",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_SIL_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_sil_width",
    ),
    ("MODULATORS", "PHASESHIFTER", "PN", "P_WIDTH"): (
        "picazzo",
        "modulators",
        "phaseshifter_pn_p_width",
    ),
}

TECHKEY_FIELD_NAME = "x-techkey"

ALL_MAPPING = MAPPING | PROCESS_MAPPING | LAYER_MAPPING


class MappingIssues:
    def __init__(self):
        self.properties_without_mapping: list[str] = []
        self.techkey_issues: list[str] = []
        self.description_issues: list[str] = []

    def note_property_without_mapping(self, path: tuple[str, ...]):
        self.properties_without_mapping.append(".".join(path))

    def note_techkey_issue(self, path: tuple[str, ...], issue: str):
        self.techkey_issues.append(f"{'.'.join(path)}.{TECHKEY_FIELD_NAME}: {issue}")

    def note_description_should_contain(self, path: tuple[str, ...], expected_contents: str):
        self.description_issues.append(f'{".".join(path)}.description: should contain "{expected_contents}"')

    def report(self):
        if self.properties_without_mapping:
            print("Found schema properties with missing mappings:")
            for issue in self.properties_without_mapping:
                print(f"  - {issue}")
        else:
            print("No missing mappings found.")

        if self.techkey_issues:
            print("Found techkey field issues:")
            for issue in self.techkey_issues:
                print(f"  - {issue}")
        else:
            print("No mismatched techkey fields found.")

        if self.description_issues:
            print("Found description issues:")
            for issue in self.description_issues:
                print(f"  - {issue}")
        else:
            print("No description field issues found.")


class ParsedPropertyNode:
    def __init__(
        self,
        path: tuple[str, ...],
        node: dict[str, Any],
        techkeymap_new_to_old: dict[tuple[str, ...], tuple[str, ...]],
    ):
        self.path = path
        self.node = node
        if self.path in techkeymap_new_to_old:
            self.old_key: str | None = f"TECH.{'.'.join(techkeymap_new_to_old[self.path])}"
        else:
            self.old_key = None
        default_field = self.node.get("default")
        if default_field is not None:
            self.default = str(default_field)
            if len(self.default) == 0:
                self.default = None
        else:
            self.default = None
        self.description: str | None = None
        self.techkey_from_description: str | None = None
        self.default_from_description: str | None = None
        self._parse_description()

    @classmethod
    def _techkey_label(cls):
        return "technology-key: "

    @classmethod
    def _default_label(cls):
        return "default: "

    def _parse_description(self):
        if "description" not in self.node:
            return
        description_with_labels = self.node.get("description")
        if not isinstance(description_with_labels, str):
            return
        description_parts = description_with_labels.split(self._techkey_label(), maxsplit=1)
        if len(description_parts) > 1 and len(description_parts[1]) > 0:
            self.techkey_from_description = description_parts[1].strip()
        if len(description_parts[0]) > 0:
            description_with_labels = description_parts[0]
        description_parts = description_with_labels.split(self._default_label(), maxsplit=1)
        if len(description_parts) > 1 and len(description_parts[1]) > 0:
            self.default_from_description = description_parts[1].strip()
        if len(description_parts[0]) > 0:
            self.description = description_parts[0].strip()

    def note_missing_mapping(self, mappingIssues: MappingIssues):
        if self.old_key is None:
            mappingIssues.note_property_without_mapping(self.path)

    def note_techkey_field_issue(self, mappingIssues: MappingIssues):
        techkey_field = self.node.get(TECHKEY_FIELD_NAME)
        if self.old_key != techkey_field:
            if self.old_key is None:
                mappingIssues.note_techkey_issue(self.path, f'"{techkey_field}" does not exist')
            elif techkey_field is None:
                mappingIssues.note_techkey_issue(self.path, f'missing value (expected "{self.old_key}")')
            else:
                mappingIssues.note_techkey_issue(self.path, f'expected "{self.old_key}" instead got "{techkey_field}"')

    def corrected_full_description(self) -> None | str:
        parts: list[str] = []
        if self.description is not None:
            parts.append(self.description)
        if self.default is not None:
            parts.append(f"{self._default_label()}{self.default}")
        if self.old_key is not None:
            parts.append(f"{self._techkey_label()}{self.old_key}")
        if len(parts) == 0:
            return None
        else:
            return " ".join(parts)

    def note_description_field_issue(self, mappingIssues: MappingIssues):
        if self.old_key != self.techkey_from_description:
            mappingIssues.note_description_should_contain(self.path, f"{self._techkey_label()}{self.old_key}")
        if self.default != self.default_from_description:
            mappingIssues.note_description_should_contain(self.path, f"{self._default_label()}{self.default}")

    def set_techkey_field(self):
        techkey_field = self.node.get(TECHKEY_FIELD_NAME)
        if self.old_key is None:
            if techkey_field is not None:
                del self.node[TECHKEY_FIELD_NAME]
        else:
            self.node[TECHKEY_FIELD_NAME] = self.old_key

    def set_description(self):
        full_description = self.corrected_full_description()
        if full_description is None:
            if "description" in self.node:
                del self.node["description"]
        else:
            self.node["description"] = full_description


def check_mappings(schema: dict[str, Any], mapping: dict[Any, Any], adapt_fields: bool) -> MappingIssues:
    """
    Recursively traverses the schema

    Report properties that are not in the mapping
    Report missing or wrong techkey fields

    If adapt_fields is True, the input schema will be adapted in-place (overwrite existing, remove unneeded)

    An x-techkey field should literally mention the mapping starting by "TECH."
        For instance, given this mapping:
        ("WG", "SPACING"): ("waveguides", "wg_spacing")
        The schema field properties.waveguides.wg_spacing.techkey should be defined as:
        "x-techkey": "TECH.WG.SPACING"

    Description fields should also repeat the techkey
        Repeating the techkey in the description is a convenience for Pycharm users.
        Indeed, when opening tech.yaml in Pycharm, the on-hover text reveals the description only.
        Given the same example as above, the description should end with:
        "x-techkey: TECH.WG.SPACING"

    Args:
        schema (dict): The JSON schema.
        mapping (dict): The dictionary mapping old keys to new keys.

    Returns:
        A tuple of two types of issues:
         - a list of missing properties
         - a list of non-matching techkey fields
    """
    mappingIssues = MappingIssues()
    reverse_mapping = {v: k for k, v in mapping.items()}

    def _traverse(node: dict[str, Any], path: tuple[str, ...] = ()):
        if not isinstance(node, dict):
            return

        if "properties" in node:
            for key, sub_node in node["properties"].items():
                current_path = path + (key,)
                if "properties" in sub_node and isinstance(sub_node["properties"], dict):
                    _traverse(sub_node, current_path)
                else:
                    current_node = ParsedPropertyNode(
                        path=current_path,
                        node=sub_node,
                        techkeymap_new_to_old=reverse_mapping,
                    )
                    current_node.note_missing_mapping(mappingIssues)
                    current_node.note_techkey_field_issue(mappingIssues)
                    current_node.note_description_field_issue(mappingIssues)
                    if adapt_fields:
                        current_node.set_techkey_field()
                        current_node.set_description()

    _traverse(schema)
    return mappingIssues


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process a tech.yaml schema file and sanity check its mappings.")
    parser.add_argument("input_schema", type=Path, help="Path to the input schema.json file.")
    parser.add_argument("-o", "--output-schema", type=Path, help="Path for the output schema.json file (Optional).")
    args = parser.parse_args()

    schema_path = args.input_schema
    schema_out_filename = args.output_schema

    with schema_path.open("r") as f:
        schema_data = json.load(f)

    mappingIssues = check_mappings(schema_data, ALL_MAPPING, adapt_fields=schema_out_filename is not None)

    mappingIssues.report()

    reverse_mapping = {v: k for k, v in ALL_MAPPING.items()}

    if schema_out_filename is not None:
        with open(schema_out_filename, "w") as schema_out_file:
            json.dump(schema_data, schema_out_file, indent=2)
