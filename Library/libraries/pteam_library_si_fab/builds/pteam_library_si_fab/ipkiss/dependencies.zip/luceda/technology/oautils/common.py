def is_layoutcell(view_cls):
    """Test if this view is a LayoutCell.Layout.

    We assume a user uses these classes for storing layout data

    This is used to check if we want to use the IPKISS instance name of class name.

    See also
    --------
    get_cell_name

    Notes
    -----
    This is important to know for OpenAccess, because we will treat these
    components differently upon export (i.e., we treat these as fixed cells of which
    we export the data (elements, ports), instead of calculating them as we do in regular
    Layout views)
    """
    from ipkiss3.shortcuts import LayoutCell
    from ipkiss.io.input_gdsii import GDSIIStructure

    return view_cls is LayoutCell.Layout or view_cls is GDSIIStructure.Layout


def get_cell_name(view):
    """Get the cell name, which uniquely identifies this component (unique if you include the ipkiss properties,
     in case the component is not static)

    In most cases, just use the class name (class name + ipkiss properties (if any) uniquely identifies the component).
    In case the component is a fixed LayoutCell.Layout, use the actual cell name (here, the cell name
    uniquely identifies the component)

    Notes
    -----
    * This is used during the OpenAccess exporter
    * We treat LayoutCell.Layout different, because we assume they are uniquely identified by the
        user-set name.
    """
    if is_layoutcell(type(view)):
        return view.name
    return type(view.cell).__name__
