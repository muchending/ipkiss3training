# Copied from oa_tools
from ipcore.properties.predefined import NonNegativeIntProperty, DictProperty
from ipkiss.process import PatternPurpose, ProcessLayer
from collections import namedtuple
from collections.abc import MutableMapping

__all__ = ["AutoOALayerExportMap", "AutoOAPurposeExportMap"]

oa_Layer = namedtuple("oa_Layer", ["name", "number"])
oa_Purpose = namedtuple("oa_Purpose", ["name", "number"])


class AutoOALayerExportMap(MutableMapping):
    """Maps Ipkiss ProcessLayers to (name, number) pairs for oaLayers"""

    def __init__(self, known_layers=None, base_counter=1000):
        super().__init__()
        if known_layers is None:
            known_layers = dict()

        not_processlayers = [layer for layer in known_layers.keys() if not isinstance(layer, ProcessLayer)]

        if len(not_processlayers) > 0:
            raise TypeError(f"{not_processlayers} are not ProcessLayers")

        self._known_layers = {
            layer: layer_no for layer, layer_no in known_layers.items() if isinstance(layer, ProcessLayer)
        }

        self._base_counter = base_counter

    def __getitem__(self, key, default=None):
        if not hasattr(self, "_layernum"):
            self._layernum = self._base_counter

        if key not in self._known_layers:
            if default:
                return default

            self._known_layers[key] = self._layernum
            self._layernum += 1

        return oa_Layer(key.extension, self._known_layers[key])

    def __setitem__(self, key, number):
        self._known_layers[key] = number

    def __delitem__(self, key):
        self._known_layers.__delitem__(key)

    def __len__(self):
        return len(self._known_layers)

    def __iter__(self):
        return iter(self._known_layers)


class AutoOAPurposeExportMap(MutableMapping):
    """Maps Ipkiss PatternPurposes to (name, number) pairs for oaPurposes"""

    base_counter = NonNegativeIntProperty(default=1000, doc="starting counter for the oa purpose number")
    known_purposes = DictProperty(doc="prefilled purpose:number map")

    def __init__(self, known_purposes=None, base_counter=1000):
        super().__init__()
        self._reserved_purposes = {
            PatternPurpose("Drawing", "DRW"): ("drawing", 0xFFFFFFFF),
            PatternPurpose("Drawing", "DRAWING"): ("drawing", 0xFFFFFFFF),
        }
        self._reserved_purposes_by_casefold_extension = {
            purpose.extension.casefold(): value for purpose, value in self._reserved_purposes.items()
        }
        self._base_counter = base_counter
        if known_purposes is None:
            known_purposes = dict()

        not_purpose = [purpose for purpose in known_purposes.keys() if not isinstance(purpose, PatternPurpose)]

        if len(not_purpose) > 0:
            raise TypeError(f"{not_purpose} are not PatternPurposes")

        self._known_purposes = {
            purpose: purpose_no for purpose, purpose_no in known_purposes.items() if isinstance(purpose, PatternPurpose)
        }

    def __getitem__(self, key: PatternPurpose, default=None):
        if not hasattr(self, "_purposenum"):
            self._purposenum = self._base_counter

        reserved_key = self._reserved_purposes_by_casefold_extension.get(key.extension.casefold(), None)
        if reserved_key:
            return oa_Purpose(reserved_key[0], reserved_key[1])

        if key not in self._known_purposes:
            self._known_purposes[key] = self._purposenum
            self._purposenum += 1

        return oa_Purpose(key.extension, self._known_purposes[key])

    def __setitem__(self, key, number):
        self._known_purposes[key] = number

    def __delitem__(self, key):
        self._known_purposes.__delitem__(key)

    def __len__(self):
        return len(self._known_purposes) + len(self._reserved_purposes)

    def __iter__(self):
        return iter(list(self._reserved_purposes.keys()) + list(self._known_purposes.keys()))
