# Copied from oa_tools
"""A multiple dispatch that filters layout elements according to predefined layout filters.


For example:

    to_oa = FilteredDispatcher('to_oa', layout_filter=ipkiss_tech.OPENACCESS.FILTER)

    @to_oa.register(i3.Boundary, ...):
        # Create a boundary in OA based on an ipkiss i3.Boundary
        return oa_boundary

The filters are preprocessing functions that operate on the layout data.
For example, to cut boundaries into small pieces (BoundaryCutFilter, PathToBoundaryFilter, ...).
This is used in preparation to write the IPKISS layout to a data format such as GDSII, OpenAccess, ...

"""

from multipledispatch import Dispatcher
from collections.abc import Sequence, Mapping


class FilteredDispatcher(Dispatcher):
    __slots__ = Dispatcher.__slots__ + ("layout_filter",)

    def __init__(self, name, doc=None, layout_filter=None):
        super().__init__(name, doc)
        from ipkiss3.pcell.layout.elements.basic import ElementList

        def _filter(obj):
            filtered = layout_filter(obj)
            if isinstance(obj, ElementList) and not isinstance(filtered, ElementList):
                return ElementList(filtered)

            return filtered

        self.layout_filter = _filter

    def __call__(self, *args, **kwargs):
        if self.layout_filter:
            new_obj = self.layout_filter(args[0])
            if (
                isinstance(new_obj, (Sequence, Mapping))
                and len(new_obj) == 1
                and not (isinstance(args[0], (Sequence, Mapping)))
            ):
                # do not iterate if it's just a list with a single object and the input was not a list with
                # a single object sequence and mapping to capture ElementList and InstanceDict
                # [[a ,b ]] -> [a, b]
                # [[a]] -> [a]
                new_obj = new_obj[0]
            args = (new_obj,) + args[1:]
        return super().__call__(*args, **kwargs)
