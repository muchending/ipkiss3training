from ipkiss import __version__ as ipkiss_version
from ipkiss.technology import technology
from packaging.version import Version


if Version(ipkiss_version.split()[-1].split("_")[-1]) <= Version("2025.06"):
    # extend the TechnologyLibrary so that it uses the updated code
    # for older ipkiss versions.
    from ipcore.config.tree import ComputedValue, ConfigTree

    class TechnologyLibrary(technology.TechnologyLibrary):
        """A specific type of ConfigTree: its representation is: <TECH...>"""

        def __init__(self, name: str, description: str | None = None, defaults: bool = False):
            super().__init__(name, description, defaults=False)
            self._cache: dict[str, object] = {}
            if defaults:
                self._prefill_defaults()

        def __repr__(self):
            return f"<TECH {self.name}>"

        def _set_default(self, path: str, default_val: object, set_overwrite_flag: bool = False):
            parts = path.split(".")
            node: ConfigTree = self
            from .defaults import DerivedDefaultValue, Feature, MissingKeyForFeature

            if isinstance(default_val, DerivedDefaultValue):
                derived_default = default_val
                func = derived_default.func
                _cache = self._cache

                def _func[T]():
                    if repr(func) in _cache:
                        return _cache[repr(func)]

                    val = derived_default(self)
                    _cache[repr(func)] = val

                    return val

                default_val = ComputedValue(_func)
            elif isinstance(default_val, Feature):
                default_val = MissingKeyForFeature(key=path, feature=default_val)

            for part in parts[:-1]:
                subtree = getattr(node, part, None)
                if subtree is None:
                    subtree = technology.TechnologyTree()
                    if set_overwrite_flag:
                        node.overwrite_allowed.append(part)
                    setattr(node, part, subtree)
                node = subtree
            attr = parts[-1]
            if not hasattr(node, attr):
                if set_overwrite_flag:
                    node.overwrite_allowed.append(attr)
                setattr(node, attr, default_val)

        def _prefill_defaults(self):
            """Assign defaults"""
            from .defaults import DEFAULTS

            for path, default_val in DEFAULTS.items():
                self._set_default(path, default_val, set_overwrite_flag=True)

        def finalize(self):
            """Assign missing defaults and declare tree as finalized"""
            if self.finalized:
                raise ValueError(f"{self} is already finalized")

            from .defaults import fill_defaults

            fill_defaults(self)
            self.finalized = True
else:
    TechnologyLibrary = technology.TechnologyLibrary
