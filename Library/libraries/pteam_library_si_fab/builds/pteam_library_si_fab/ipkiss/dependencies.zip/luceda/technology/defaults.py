"""
This file contains defaults for the technology tree

There are 3 types of 'defaults':

- simple (integer, float, str, ...) default values
- complex (object, trace templates, pcells) default values
- derived default values

Aside from these there's also the category 'MissingKeyForFeature' which indicates that this key doesn't have
a default but is only required when you use a certain feature.

simple default values need to be defined as much as possible in the schema, all default values mentioned in
schema_defaults are derived automatically during build from the schema.json

Complex default values we want to avoid as much as possible and are mostly there because of legacy reasons.

Derived default values are also to be avoided as much as possible, but in case they're needed they're implemented in
this file using the derived_default decorator
"""

from collections import deque
import warnings
from collections.abc import Mapping, Callable
from operator import attrgetter
from typing import TYPE_CHECKING, Any, NamedTuple

from ipcore.config.tree import ComputedValue
from ipkiss.primitives.name_generator import CounterNameGenerator
from ipkiss.process.layer import ProcessLayer, PatternPurpose, PPLayer
from ipkiss.technology.technology import ProcessTechnologyTree, TechnologyLibrary

if TYPE_CHECKING:
    from ipkiss.primitives.layer import Layer
    from ipkiss3.pcell.blocks.adapter import IoBlockAdapter
    from ipkiss3.pcell.library import Library
    from ipkiss.visualisation.display_style import DisplayStyleSet
    from ipkiss3.pcell.wiring.trace import ElectricalWireTemplate
    from ipkiss3.pcell.trace.transitions.auto_transition.auto_transition_db import AutoTransitionDatabase
    from ipkiss.geometry.shapes.basic import ShapeRectangle
    from ipkiss.primitives.filter import ToggledCompoundFilter
    from ipkiss.primitives.filters.name_scramble_filter import NameScrambleFilter
    from ipkiss.io.gds_layer import AutoGdsiiLayerOutputMap, AutoGdsiiLayerInputMap

from .schema_defaults import DEFAULT_VALUES as SCHEMA_DEFAULTS


## IPKISS defaults
##################


class DerivedDefaultValue[T]:
    deps: tuple[str, ...]
    func: Callable[..., T]

    def __init__(self, deps: tuple[str, ...], func: Callable[..., T]) -> None:
        self.deps = deps
        self.func = func

    def __call__(self, tech: TechnologyLibrary) -> Any:
        deps = [attrgetter(d)(tech) for d in self.deps]
        return self.func(*deps)


def derived_default(
    *dependencies: str,
):
    def _decorator[T](func: Callable[..., T]) -> DerivedDefaultValue[T]:
        return DerivedDefaultValue(deps=dependencies, func=func)

    return _decorator


class MissingKeyForFeature(ComputedValue[None]):
    def __init__(self, key: str, feature: "Feature") -> None:
        super().__init__(self._func)
        self.key = key
        self.feature = feature

    def _func(self) -> None:
        raise LookupError(f"Technology key TECH.{self.key} required for feature '{self.feature.name}'")


class Feature(NamedTuple):
    name: str


PICAZZO_CURVED_FIBCOUP = Feature("Picazzo's curved fiber couplers")
PICAZZO_FIBCOUP = Feature("Picazzo's curved fiber couplers")
PICAZZO_STRAIGHT_FIBCOUP = Feature("Picazzo's straight fiber couplers")
IOCOLUMN = Feature("IO Column")
VIAS = Feature("VIAS")


@derived_default()
def port_layer() -> "Layer":
    from ipkiss.primitives.layer import Layer

    return Layer(2)


@derived_default()
def ioblock_adapter() -> "IoBlockAdapter":
    from ipkiss3.pcell.blocks.adapter import IoBlockAdapter

    return IoBlockAdapter()


@derived_default("METRICS.UNIT", "METRICS.GRID")
def techlib(unit: float, grid: float) -> "Library":
    from ipkiss3.pcell.library import Library

    return Library("TECHLIB", unit=unit, grid=grid)


@derived_default()
def default_style_set() -> "DisplayStyleSet":
    from ipkiss.visualisation.color import (
        COLOR_BLACK,
        COLOR_BLUE,
        COLOR_CYAN,
        COLOR_GREEN,
        COLOR_MAGENTA,
        COLOR_RED,
        COLOR_YELLOW,
    )
    from ipkiss.visualisation.display_style import DisplayStyle, DisplayStyleSet

    cycle_colors = [COLOR_BLACK, COLOR_RED, COLOR_GREEN, COLOR_BLUE, COLOR_MAGENTA, COLOR_YELLOW, COLOR_CYAN]
    default_styles = [DisplayStyle(color=c, alpha=0.5) for c in cycle_colors]
    return DisplayStyleSet([(i, default_styles[i % len(default_styles)]) for i in range(256)])


@derived_default("PCELLS.LIB")
def pcells_metal_wire(pcells_lib: "Library") -> "ElectricalWireTemplate":
    from ipkiss3.pcell.wiring.trace import ElectricalWireTemplate

    return ElectricalWireTemplate(name="DEFAULT_WIRE_TEMPLATE", library=pcells_lib)


@derived_default("PCELLS.METAL.WIRE")
def pcells_metal_default(pcells_metal_wire: "ElectricalWireTemplate") -> "ElectricalWireTemplate":
    return pcells_metal_wire


@derived_default()
def auto_transition_database() -> "AutoTransitionDatabase":
    from ipkiss3.pcell.trace.transitions.auto_transition.auto_transition_db import AutoTransitionDatabase

    return AutoTransitionDatabase()


@derived_default()
def layer_0() -> "Layer":
    from ipkiss.primitives.layer import Layer

    return Layer(0)


@derived_default()
def layer_1() -> "Layer":
    from ipkiss.primitives.layer import Layer

    return Layer(1)


@derived_default()
def via_default_metal_shape() -> "ShapeRectangle":
    from ipkiss.geometry.shapes.basic import ShapeRectangle

    return ShapeRectangle(box_size=(0.6, 0.6))


@derived_default()
def via_default_via_shape() -> "ShapeRectangle":
    from ipkiss.geometry.shapes.basic import ShapeRectangle

    return ShapeRectangle(box_size=(0.5, 0.5))


@derived_default()
def process_tree() -> ProcessTechnologyTree:
    return ProcessTechnologyTree()


IPKISS_DEFAULTS = {
    "ADMIN.NAME_GENERATOR": CounterNameGenerator(
        prefix_attribute="_name_prefix",
        counter_zero=0,
        default_prefix="PCELL",
    ),
    "DISPLAY.PREDEFINED_STYLE_SETS.CYCLIC": default_style_set,
    "MASK.POLARITY_DF": "DF",
    "MASK.POLARITY_LF": "LF",
    "PCELLS.LIB": techlib,
    "PCELLS.METAL.DEFAULT": pcells_metal_default,
    "PCELLS.METAL.WIRE": pcells_metal_wire,
    "PCELLS.TRANSITION.AUTO_TRANSITION_DATABASE": auto_transition_database,
    "PORT.DEFAULT_LAYER": port_layer,
    "PORT.DEFAULT_LENGTH": 0.1,
    "IO.ADAPTER.DEFAULT_ADAPTER.ADAPTER": ioblock_adapter,
}

PDK_REQ_DEFAULTS = {
    # re-added after DOT-7929
    "DEFAULT_WAVELENGTH": 1.55,  # camfr wg model
    "TRACE.BEND_RADIUS": 5.0,  # used across ipkiss
    # "WG.ANGLE_STEP": 1.0, # not used
    # "WG.BEND_RADIUS": 5.0, # not used
    "WG.EXPANDED_STRAIGHT": 5.0,  # used in ipkiss
    # "WG.EXPANDED_TAPER_LENGTH": 3.0, deprecated ExpandedWaveguide and picazzo3
    # "WG.EXPANDED_WIDTH": 0.8, deprecated ExpandedWaveguide and picazzo3
    # "WG.OVERLAP_EXTENSION": 0.02, # not used
    # "WG.OVERLAP_TRENCH": 0.01, # not used
    "WG.SHORT_STRAIGHT": 2.0,  # used in ipkiss
    # "WG.SLOT_WIDTH": 0.15, not used
    "WG.SPACING": 2.0,  # used across ipkiss
    "WG.TRENCH_WIDTH": 2.0,  # sifab samples picazzo3 pdks
    "WG.WIRE_WIDTH": 0.45,  # camfr
    "WG_DEFAULTS.LOSS_DB_PERM": 0.0,  # wg model
    "WG_DEFAULTS.N_EFF": 1.0,  # wg model
    "WG_DEFAULTS.N_GROUP": 2.0,  # wg model
}
PDK_DELAYED_DEFAULTS = {
    "PROCESS": process_tree,
}
## GDSII defaults
##################


@derived_default(
    "GDSII.MAX_COORDINATES",
    "METRICS.UNIT",
    "METRICS.GRID",
    "GDSII.MAX_VERTEX_COUNT",
    "GDSII.STRNAME_ALLOWED_CHARACTERS",
)
def gdsii_filter(
    max_coords: float,
    unit: int,
    grid: int,
    max_vertex_count: int,
    allowed_chars: str,
) -> "ToggledCompoundFilter":
    from ipkiss.primitives.filters.path_cut_filter import PathCutFilter
    from ipkiss.primitives.filters.empty_filter import EmptyFilter
    from ipkiss.primitives.filters.path_to_boundary_filter import PathToBoundaryFilter
    from ipkiss.primitives.filters.boundary_cut_filter import BoundaryCutFilter
    from ipkiss.primitives.filters.name_error_filter import PCellNameErrorFilter
    from ipkiss.primitives.filter import ToggledCompoundFilter

    f = ToggledCompoundFilter()
    f += PathCutFilter(
        name="cut_path",
        max_path_length=max_coords,
        grids_per_unit=int(unit / grid),
        overlap=1,
    )
    f["cut_path"] = True
    f += PathToBoundaryFilter(name="path_to_boundary")
    f["path_to_boundary"] = True
    f += BoundaryCutFilter(name="cut_boundary", max_vertex_count=max_vertex_count)
    f["cut_boundary"] = True
    f += EmptyFilter(name="write_empty")
    f["write_empty"] = True
    f += PCellNameErrorFilter(name="name_error_filter", allowed_characters=allowed_chars)
    f["name_error_filter"] = False
    return f


@derived_default(
    "GDSII.STRNAME_ALLOWED_CHARACTERS",
    "GDSII.STRNAME_CHARACTER_DICT",
    "GDSII.MAX_NAME_LENGTH",
)
def gdsii_name_filter(allowed_chars: str, char_dict: Mapping[str, str], max_name_length: str) -> "NameScrambleFilter":
    from ipkiss.primitives.filters.name_scramble_filter import NameScrambleFilter

    return NameScrambleFilter(
        allowed_characters=allowed_chars,
        replace_characters=char_dict,
        default_replacement="",
        max_name_length=max_name_length,
        scramble_all=False,
    )


@derived_default()
def output_map() -> "AutoGdsiiLayerOutputMap":
    from ipkiss.io.gds_layer import AutoGdsiiLayerOutputMap

    return AutoGdsiiLayerOutputMap()


@derived_default()
def input_map() -> "AutoGdsiiLayerInputMap":
    from ipkiss.io.gds_layer import AutoGdsiiLayerInputMap

    return AutoGdsiiLayerInputMap()


@derived_default("PROCESS")
def error_purpose(_) -> PatternPurpose:
    # not defined as a direct value as purposes are global
    return PatternPurpose(name="Error", extension="ERROR", doc="Errors")


@derived_default("PROCESS")
def none_process(_) -> ProcessLayer:
    # not defined as a direct value as processes are global
    return ProcessLayer(name="No process", extension="NONE")


@derived_default(
    "PROCESS.NONE",
    "PURPOSE.ERROR",
)
def error_pplayer(none_process: ProcessLayer, error_purpose: PatternPurpose) -> PPLayer:
    return PPLayer(process=none_process, purpose=error_purpose, name="ERROR")  # Generic Error indication


# in practice these are virtually unused
ERROR_DEFAULTS = {
    "PURPOSE.ERROR": error_purpose,
    "PROCESS.NONE": none_process,
    "PPLAYER.ERROR.GENERIC": error_pplayer,
    "PPLAYER.ERROR.CROSSING": error_pplayer,
}

GDSII_DEFAULTS = {
    "GDSII.NAME_FILTER": gdsii_name_filter,
    "GDSII.FILTER": gdsii_filter,
    "GDSII.EXPORT_LAYER_MAP": output_map,
    "GDSII.IMPORT_LAYER_MAP": input_map,
}


@derived_default("WG.WIRE_WIDTH", "WG.TRENCH_WIDTH")
def wg_cladding_width(wire_width: float, trench_width: float) -> float:
    return wire_width + 2 * trench_width


@derived_default("WG.WIRE_WIDTH")
def wg_dc_spacing(wire_width: float) -> float:
    return wire_width + 0.18


@derived_default("WG.SHORT_TRANSITION_LENGTH")
def wg_short_taper_length(short_transition_length: float) -> float:
    return short_transition_length


WAVEGUIDE_DEFAULTS = {
    "WG.CLADDING_WIDTH": wg_cladding_width,
    "WG.DC_SPACING": wg_dc_spacing,
    "WG.SHORT_TAPER_LENGTH": wg_short_taper_length,
    "WG_DEFAULTS.CORE_LAYER": layer_0,
    "TRACE.CONTROL_SHAPE_LAYER": layer_1,
    "TRACE.DEFAULT_LAYER": layer_0,
}

ELECTRICAL_DEFAULTS = {
    "METAL.LINE_WIDTH": 0.5,
    "VIAS.DEFAULT.BOTTOM_SHAPE": via_default_metal_shape,
    "VIAS.DEFAULT.TOP_SHAPE": via_default_metal_shape,
    "VIAS.DEFAULT.VIA_SHAPE": via_default_via_shape,
}


# The purpose layers not defined as a direct value as purposes are global


@derived_default("PURPOSE")
def purpose_drawing(_) -> PatternPurpose:
    return PatternPurpose(name="Drawing", extension="DRW")


@derived_default("PURPOSE")
def purpose_doc(_) -> PatternPurpose:
    return PatternPurpose(name="Documentation", extension="DOC")


@derived_default("PURPOSE")
def purpose_trace(_) -> PatternPurpose:
    return PatternPurpose(name="Routing trace", extension="TRACE")


@derived_default("PURPOSE")
def purpose_pinrec(_) -> PatternPurpose:
    return PatternPurpose(name="Pin recognition", extension="PINREC")


@derived_default("PURPOSE")
def purpose_devrec(_) -> PatternPurpose:
    return PatternPurpose(name="Device recognition", extension="DEVREC")


@derived_default("PURPOSE")
def purpose_bbox(_) -> PatternPurpose:
    return PatternPurpose(name="Bounding Box", extension="BBOX")


@derived_default("PURPOSE")
def purpose_simbnd(_) -> PatternPurpose:
    return PatternPurpose(name="Simulation boundary", extension="SIMBND")


@derived_default("PURPOSE")
def purpose_ignore(_) -> PatternPurpose:
    return PatternPurpose(name="Ignored", extension="IGNORE")


PURPOSE_DEFAULTS = {
    "PURPOSE.DRAWING": purpose_drawing,
    "PURPOSE.DOC": purpose_doc,
    "PURPOSE.TRACE": purpose_trace,
    "PURPOSE.PINREC": purpose_pinrec,
    "PURPOSE.DEVREC": purpose_devrec,
    "PURPOSE.BBOX": purpose_bbox,
    "PURPOSE.SIMBND": purpose_simbnd,
    "PURPOSE.IGNORE": purpose_ignore,
}

IOCOLUMN_DEFAULTS = {
    "IO.ADAPTER.IOFIBCOUP.FANOUT_LENGTH": IOCOLUMN,
    "IO.ADAPTER.IOFIBCOUP.S_BEND_ANGLE": IOCOLUMN,
    "IO.FIBCOUP.DEFAULT.PCELLS.DEFAULT_GRATING": IOCOLUMN,
    "IO.FIBCOUP.DEFAULT.SOCKET.LENGTH": IOCOLUMN,
    "BLOCKS.DEFAULT_WIDTH": IOCOLUMN,
    "BLOCKS.DEFAULT_YSPACING": IOCOLUMN,
}


FIBCOUP_DEFAULTS = {
    "IO.FIBCOUP.CURVED.SOCKET.MARGIN_FROM_GRATING": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.GRATING.ANGLE_SPAN": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.GRATING.BOX_WIDTH": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.GRATING.FOCAL_DISTANCE": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.GRATING.N_O_LINES": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.GRATING.PERIOD": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.GRATING.START_RADIUS": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.PCELLS.DEFAULT_GRATING": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.SOCKET.LENGTH": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.SOCKET.START_TRACE_TEMPLATE": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.SOCKET.STRAIGHT_EXTENSION": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.CURVED.SOCKET.WIDE_TRACE_TEMPLATE": PICAZZO_CURVED_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.GRATING.BOX_WIDTH": PICAZZO_STRAIGHT_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.GRATING.LINE_WIDTH": PICAZZO_STRAIGHT_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.GRATING.N_O_LINES": PICAZZO_STRAIGHT_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.GRATING.PERIOD": PICAZZO_STRAIGHT_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.PCELLS.DEFAULT_GRATING_TM": PICAZZO_STRAIGHT_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.SOCKET.LENGTH": PICAZZO_STRAIGHT_FIBCOUP,
    "IO.FIBCOUP.STRAIGHT.SOCKET.TRACE_TEMPLATE": PICAZZO_STRAIGHT_FIBCOUP,
}

VIA_DEFAULTS = {
    "VIAS.DEFAULT.TOP_SHAPE": VIAS,
    "VIAS.DEFAULT.BOTTOM_SHAPE": VIAS,
    "VIAS.DEFAULT.VIA_SHAPE": VIAS,
    "VIAS.CONTACT_HOLE.M1_WIDTH": VIAS,
    "VIAS.CONTACT_HOLE.PCELLS.DEFAULT_VIA": VIAS,
    "VIAS.CONTACT_HOLE.SIL_WIDTH": VIAS,
    "VIAS.CONTACT_HOLE.VIA_WIDTH": VIAS,
    "VIAS.V12.M1_WIDTH": VIAS,
    "VIAS.V12.M2_WIDTH": VIAS,
    "VIAS.V12.N_O_SIDES": VIAS,
    "VIAS.V12.PCELLS.DEFAULT_VIA": VIAS,
    "VIAS.V12.VIA_WIDTH": VIAS,
}


DEFAULTS = (
    PDK_DELAYED_DEFAULTS
    | SCHEMA_DEFAULTS
    | IPKISS_DEFAULTS
    | GDSII_DEFAULTS
    | WAVEGUIDE_DEFAULTS
    | ELECTRICAL_DEFAULTS
    | ERROR_DEFAULTS
    | PURPOSE_DEFAULTS
    | VIA_DEFAULTS
    | FIBCOUP_DEFAULTS
    | IOCOLUMN_DEFAULTS
    | PDK_REQ_DEFAULTS
)

UNSET = object()


def resolve_defaults(tech: TechnologyLibrary, defaults: dict[str, object], ignore_computed_vals: bool = True):
    to_visit = deque[str]()
    to_visit.extendleft(defaults)
    keys = set(defaults.keys())
    visited: set[str] = set()

    def get(tkey: str) -> Any:
        *ancestors, leaf = tkey.split(".")
        if len(ancestors):
            try:
                parent = attrgetter(".".join(ancestors))(tech)
            except AttributeError:
                return UNSET
        else:
            parent = tech

        if ignore_computed_vals:
            dct = parent.__dict__
            if leaf not in dct:
                return UNSET
            val = dct[leaf]
            if isinstance(val, ComputedValue):
                return UNSET

            return val
        elif hasattr(parent, leaf):
            return getattr(parent, leaf)
        return UNSET

    while len(to_visit) > 0:
        k = to_visit.pop()
        val = defaults[k]
        current_val = get(k)

        if current_val is not UNSET:
            continue

        if isinstance(val, DerivedDefaultValue):
            deps = {dep: get(dep) for dep in val.deps}
            unresolved_deps = [k for k, v in deps.items() if v is UNSET]
            has_deps = len(unresolved_deps) == 0

            if has_deps and k not in visited:
                visited.add(k)
                yield k, val
            else:
                if keys.issuperset(unresolved_deps):
                    to_visit.append(k)
                    to_visit.extend(unresolved_deps)
                else:
                    visited.add(k)
                    warnings.warn(f"{k} requires {unresolved_deps} but these keys can't be resolved")
        elif isinstance(val, Feature):
            # TODO: this will only work from 2024.12 onwards
            visited.add(k)
            yield k, MissingKeyForFeature(k, val)
        elif k not in visited:
            visited.add(k)
            yield k, val


def fill_defaults(tech: TechnologyLibrary, defaults: dict[str, object] | None = None):
    from .data_to_tech import _ensure_subtree_exists

    if defaults is None:
        defaults = DEFAULTS

    for k, val in resolve_defaults(tech, defaults):
        parts = k.split(".")
        if len(parts) == 1:
            subtree = tech
        else:
            subtree = _ensure_subtree_exists(tech, ".".join(parts[:-1]))

        if isinstance(val, DerivedDefaultValue):
            setattr(subtree, parts[-1], val(tech))
        elif isinstance(val, Feature):
            default_val = MissingKeyForFeature(key=k, feature=val)
            setattr(subtree, parts[-1], default_val)
        else:
            setattr(subtree, parts[-1], val)

        subtree.overwrite_allowed.append(parts[-1])
