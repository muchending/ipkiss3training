from __future__ import annotations
import inspect
from pathlib import Path
from typing import TYPE_CHECKING

try:
    from ipkiss3 import IPKISS3_LOG as LOG
except ImportError:
    from ipkiss3 import LOG

from ipkiss.technology import get_technology

if TYPE_CHECKING:
    from luceda.technology.tech_types import PDKTechConfiguration
    from .technology_library import TechnologyLibrary


def _get_caller_dir(caller_frame: inspect.FrameInfo) -> Path:
    """Get the directory of the caller of the function that calls this function."""
    caller_filename = caller_frame.filename
    return Path(caller_filename).parent


def _load_tech_data(caller_frame: inspect.FrameInfo, filename: str | None) -> PDKTechConfiguration:
    caller_dir = _get_caller_dir(caller_frame)
    _filename = filename or "tech.yaml"
    tech_file = caller_dir / _filename

    tech_data: PDKTechConfiguration
    if not tech_file.exists():
        if filename is not None:
            raise ValueError(f"Technology file not found: {tech_file}")
        tech_data = {}
    else:
        from .data_to_tech import get_tech_data

        tech_data = get_tech_data(tech_file) or {}

    return tech_data


def load_tech(
    techname: str | None = None,
    tech: TechnologyLibrary | None = None,
    filename: str | None = None,
) -> TechnologyLibrary:
    """Loads a technology yaml into a TECH tree.

    By default looks for a tech.yaml file in the same directory as the file
    from which load_tech is being called.

    Args:
        techname: Name of the technology. If not provided, it will be derived from the root package name.
        tech: The technology library to configure. If not provided, a new one will be created.
        filename: Name of the technology file. Defaults to `tech.yaml`.

    Returns:
        The configured technology library.
    """
    from .data_to_tech import data_to_tech, get_tech_data
    from .technology_library import TechnologyLibrary

    caller_frame = inspect.stack()[1]
    tech_data = _load_tech_data(caller_frame, filename)
    lib_type = tech_data.get("type", "pdk")

    if techname is None:
        pkgname, *_ = (caller_frame.frame.f_globals.get("__package__") or "UNNAMED_TECH").split(".")
        techname = pkgname.upper()
        assert techname is not None

    if tech is None:
        if lib_type == "pdk":
            tech = TechnologyLibrary(name=techname, defaults=True)
        elif lib_type in ["adk", "tdk"]:
            from ipkiss.technology import TECHNOLOGY as tech

            if tech.name == "EMPTY_TECHNOLOGY" or tech.name == "IPKISS_DEFAULT":
                LOG.warning(
                    f"The tech.yaml you're loading is of type {lib_type}, but no PDK was loaded.",
                    stacklevel=1,
                )
    assert tech is not None

    data_to_tech(tech, tech_data)

    from ipkiss import technology

    technology.TECHNOLOGY = tech
    return tech
